import React from 'react';
import { Helmet } from 'react-helmet';

export default function History() {
  return (
    <div>
        <Helmet>
            <title>PureLink | History</title>
        </Helmet>

      <h1>History Page!!!</h1>
    </div>
  )
}
